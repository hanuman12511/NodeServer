
const homeScreenApi = async(req,res) =>{
   


}

module.exports={
    homeScreenApi
}